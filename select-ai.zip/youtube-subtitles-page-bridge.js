(() => {
  const installKey = '__selectAiYoutubePageBridgeInstalled';
  if (window[installKey]) return;
  window[installKey] = true;

  const audioTrackRequestEvent = 'select-ai-youtube-audio-tracks-request';
  const audioTrackEvent = 'select-ai-youtube-audio-tracks';
  const playerResponseRequestEvent = 'select-ai-youtube-player-response-request';
  const playerResponseEvent = 'select-ai-youtube-player-response';
  const transcriptTriggerEvent = 'select-ai-youtube-trigger-transcript';
  const transcriptEvent = 'select-ai-youtube-transcript-data';

  function getPlayer() {
    return document.querySelector('.html5-video-player.playing-mode, .html5-video-player.paused-mode')
      || document.querySelector('.html5-video-player')
      || document.getElementById('movie_player');
  }

  function emitAudioTrackData(requestId) {
    let dataJson = '';

    try {
      const player = getPlayer();
      const rawTracks = player?.getAudioTrack?.()?.captionTracks || [];
      const tracks = Array.from(rawTracks).flatMap((track) => {
        try {
          const url = track?.url || '';
          if (!url) return [];

          const parsedUrl = new URL(url, window.location.origin);
          return [{
            url,
            vssId: track?.vssId || track?.vss_id || '',
            kind: track?.kind,
            languageCode: parsedUrl.searchParams.get('lang') || track?.languageCode,
          }];
        } catch {
          return [];
        }
      });

      dataJson = JSON.stringify({
        tracks,
        device: window.ytcfg?.get?.('DEVICE') || null,
        cver: player?.getWebPlayerContextConfig?.()?.innertubeContextClientVersion || null,
      });
    } catch {
      dataJson = '';
    }

    window.dispatchEvent(new CustomEvent(audioTrackEvent, { detail: { requestId, dataJson } }));
  }

  function emitPlayerResponse(requestId) {
    let responseJson = '';

    try {
      const player = document.getElementById('movie_player');
      const response = player?.getPlayerResponse?.() || window.ytInitialPlayerResponse || null;
      responseJson = response ? JSON.stringify(response) : '';
    } catch {
      responseJson = '';
    }

    window.dispatchEvent(new CustomEvent(playerResponseEvent, { detail: { requestId, responseJson } }));
  }

  function findDeep(node, predicate, visited = new WeakSet()) {
    if (!node || typeof node !== 'object') return null;
    if (visited.has(node)) return null;
    visited.add(node);

    if (predicate(node)) return node;

    if (Array.isArray(node)) {
      for (const item of node) {
        const found = findDeep(item, predicate, visited);
        if (found) return found;
      }
      return null;
    }

    for (const value of Object.values(node)) {
      const found = findDeep(value, predicate, visited);
      if (found) return found;
    }

    return null;
  }

  function getTranscriptParams() {
    const panel = findDeep(
      window.ytInitialData,
      (node) => node && node.panelIdentifier === 'engagement-panel-searchable-transcript',
    );
    return panel?.content?.continuationItemRenderer?.continuationEndpoint?.getTranscriptEndpoint?.params || null;
  }

  function getContext() {
    const context = window.ytcfg?.get?.('INNERTUBE_CONTEXT');
    if (context) return context;

    const clientVersion = window.ytcfg?.get?.('INNERTUBE_CLIENT_VERSION') || '2.20260626.01.00';
    const clientName = window.ytcfg?.get?.('INNERTUBE_CLIENT_NAME') || 'WEB';
    return { client: { clientName, clientVersion } };
  }

  function parseMs(value) {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'string' && value.trim()) {
      const numberValue = Number(value);
      if (Number.isFinite(numberValue)) return numberValue;

      const parts = value.trim().split(':').map(Number);
      if (parts.length === 3) return ((parts[0] * 3600) + (parts[1] * 60) + parts[2]) * 1000;
      if (parts.length === 2) return ((parts[0] * 60) + parts[1]) * 1000;
    }

    return 0;
  }

  function parseText(renderer) {
    const snippet = renderer?.snippet;
    if (!snippet) return '';
    if (Array.isArray(snippet.runs)) return snippet.runs.map(run => run?.text || '').join('').trim();
    if (typeof snippet.simpleText === 'string') return snippet.simpleText.trim();
    return '';
  }

  function collectSegments(node, out, visited = new WeakSet()) {
    if (!node || typeof node !== 'object' || visited.has(node)) return false;
    visited.add(node);

    if (Array.isArray(node.initialSegments)) {
      for (const item of node.initialSegments) {
        const renderer = item?.transcriptSegmentRenderer;
        if (!renderer) continue;

        const text = parseText(renderer);
        if (!text) continue;

        out.push({
          startMs: parseMs(renderer.startMs ?? renderer.startTimeMs ?? renderer.startTimeText?.simpleText),
          endMs: parseMs(renderer.endMs ?? renderer.endTimeMs ?? renderer.endTimeText?.simpleText),
          text,
        });
      }

      return out.length > 0;
    }

    for (const value of Object.values(node)) {
      if (collectSegments(value, out, visited)) return true;
    }

    return false;
  }

  async function fetchTranscript() {
    const params = getTranscriptParams();
    const apiKey = window.ytcfg?.get?.('INNERTUBE_API_KEY');
    const context = getContext();

    if (!params || !apiKey || !context) return { segments: [] };

    const url = new URL('/youtubei/v1/get_transcript', window.location.origin);
    url.searchParams.set('key', apiKey);
    url.searchParams.set('prettyPrint', 'false');

    const response = await fetch(url.toString(), {
      method: 'POST',
      credentials: 'include',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ context, params }),
    });

    if (!response.ok) return { segments: [] };

    const json = await response.json();
    const raw = [];
    collectSegments(json, raw);

    raw.sort((a, b) => a.startMs - b.startMs);
    const segments = raw.map((segment, index) => ({
      ...segment,
      endMs: segment.endMs > segment.startMs ? segment.endMs : (raw[index + 1]?.startMs ?? (segment.startMs + 5000)),
    }));

    return { segments };
  }

  window.addEventListener(audioTrackRequestEvent, (event) => {
    emitAudioTrackData(event.detail?.requestId || '');
  });

  window.addEventListener(playerResponseRequestEvent, (event) => {
    emitPlayerResponse(event.detail?.requestId || '');
  });

  window.addEventListener(transcriptTriggerEvent, async () => {
    try {
      const result = await fetchTranscript();
      window.dispatchEvent(new CustomEvent(transcriptEvent, { detail: { segments: result.segments } }));
    } catch {
      window.dispatchEvent(new CustomEvent(transcriptEvent, { detail: { segments: [] } }));
    }
  });
})();
